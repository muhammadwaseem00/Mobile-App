﻿using System;

class StudentInfo
{
    // Fields for student information
    private string firstName;
    private string lastName;
    private int[] examGrades = new int[3];

    // Constructors
    public StudentInfo(string first, string last, int[] grades)
    {
        firstName = first;
        lastName = last;
        Array.Copy(grades, examGrades, grades.Length);
    }

    public StudentInfo()
    {
        ///firstName = "Trevis";
        //lastName = "G";
        //examGrades[3] = new int[] { 80, 75, 90 };
    }

    // Properties for student information
    public string FirstName
    {
        get { return firstName; }
        set { firstName = value; }
    }

    public string LastName
    {
        get { return lastName; }
        set { lastName = value; }
    }

    public int[] ExamGrades
    {
        get { return examGrades; }
        set { examGrades = value; }
    }

    // Function to calculate average
    public double CalculateAve()
    {
        return (examGrades[0] + examGrades[1] + examGrades[2]) / 3.0;
    }

    // Function to determine letter grade
    public char GetLetterGrade()
    {
        double average = CalculateAve();
        if (average >= 90)
            return 'A';
        else if (average >= 80)
            return 'B';
        else if (average >= 70)
            return 'C';
        else if (average >= 60)
            return 'D';
        else
            return 'F';
    }
}

class StudentInfoTest
{
    static void Main()
    {
        Console.WriteLine("Enter student information for the first student:");
        Console.Write("First Name: ");
        string fName = Console.ReadLine();

        Console.Write("Last Name: ");
        string lName = Console.ReadLine();

        int[] grades = new int[3];
        for (int i = 0; i < 3; i++)
        {
            do
            {
                Console.Write($"Enter Exam {i + 1} grade (0-100): ");
            } while (!int.TryParse(Console.ReadLine(), out grades[i]) || grades[i] < 0 || grades[i] > 100);
        }

        // Create objects of StudentInfo class
        StudentInfo student1 = new StudentInfo(fName, lName, grades);
        StudentInfo student2 = new StudentInfo();

        // Initialize object properties
       student2.FirstName = "Trvis";
        //student2.LastName = "G";
        student2.ExamGrades = new int[] { 80, 75, 90 };

        // Display information for both students
        Console.WriteLine("\nStudent 1 Information:");
        DisplayStudentInfo(student1);

        Console.WriteLine("\nStudent 2 Information:");
        DisplayStudentInfo(student2);
    }

    static void DisplayStudentInfo(StudentInfo student)
    {
        Console.WriteLine($"Student Name: {student.FirstName} {student.LastName}");
        Console.WriteLine($"Exam1: {student.ExamGrades[0]}");
        Console.WriteLine($"Exam2: {student.ExamGrades[1]}");
        Console.WriteLine($"Exam3: {student.ExamGrades[2]}");
        Console.WriteLine($"Average: {student.CalculateAve():F}");
        Console.WriteLine($"Letter Grade: {student.GetLetterGrade()}");
    }
}
